This calculation requires declaring the environment variables for mpirun as listed in the file parallel_env.sh


