# Example Package

This is a simple example package. You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.

This is the README file for the project.

The file should use UTF-8 encoding and can be written using reStructuredText or markdown with the appropriate key set. It will be used to generate the project webpage on PyPI and will be displayed as the project homepage on common code-hosting services, and should be written for that purpose.

Typical contents for this file would include an overview of the project, basic usage examples, etc. Generally, including the project changelog in here is not a good idea, although a simple “What's New” section for the most recent version may be appropriate.

python setup.py sdist bdist_wheel
