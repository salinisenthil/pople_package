export OMP_NUM_THREADS=1
export PATH=/apps/openmpi-3.0.0_install/bin:$PATH
export LD_LIBRARY_PATH=/apps/openmpi-3.0.0_install/lib:$LD_LIBRARY_PATH
